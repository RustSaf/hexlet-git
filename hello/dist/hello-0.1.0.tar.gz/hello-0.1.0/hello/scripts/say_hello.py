import colorama


def main():
    print(colorama.Fore.RED + "Hello!")
    print(colorama.Style.RESET_ALL)


if __name__ == '__main__':
    main()
